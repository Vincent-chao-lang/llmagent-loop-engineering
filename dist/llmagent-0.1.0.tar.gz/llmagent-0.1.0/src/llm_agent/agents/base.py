"""
LLM Agent基类

专门的LLM Agent实现，以LLM为核心，
具备记忆、规划、反思等AI能力。
"""

import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import uuid


@dataclass
class AgentResponse:
    """Agent响应"""
    content: str
    tool_calls: List[Dict] = field(default_factory=list)
    reasoning: str = ""
    confidence: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionPlan:
    """执行计划"""
    goal: str
    steps: List[Dict] = field(default_factory=list)
    estimated_time: int = 0
    required_tools: List[str] = field(default_factory=list)

    def remaining_steps(self) -> List[Dict]:
        """获取剩余步骤"""
        # 简化实现，实际应该跟踪执行进度
        return self.steps

    def update(self, new_plan_content: str) -> None:
        """更新执行计划

        根据新的计划内容更新当前步骤。
        用于动态重规划场景。

        Args:
            new_plan_content: 新的计划内容（LLM生成的文本）
        """
        # 简化实现：解析新内容并更新步骤
        # 实际应该有更复杂的解析逻辑，保持已完成的步骤
        import re
        # 尝试提取步骤（简单实现）
        step_patterns = re.findall(r'(?:步骤|step)\s*\d+[:\.]\s*([^\n]+)', new_plan_content, re.IGNORECASE)
        if step_patterns:
            self.steps = [{"description": s.strip(), "step_type": "thinking"} for s in step_patterns]
            self.estimated_time = len(self.steps) * 60  # 重新估算时间
        # 如果解析失败，保持原计划不变


@dataclass
class ExecutionResult:
    """执行结果"""
    success: bool
    steps: List[Any] = field(default_factory=list)
    reflection: Optional[str] = None
    error: Optional[str] = None


@dataclass
class Reflection:
    """反思结果"""
    insights: str
    improvements: str
    lessons_learned: str


@dataclass
class MemoryContext:
    """记忆上下文"""
    long_term: List[Any] = field(default_factory=list)
    short_term: List[Any] = field(default_factory=list)
    working: Dict[str, Any] = field(default_factory=dict)


class LLMAgent:
    """专门的LLM Agent

    特点：
    - LLM为核心，不是外挂组件
    - 具备完整的记忆系统
    - 能够自主规划和执行
    - 支持工具的智能调用
    - 具备反思和改进能力
    """

    def __init__(
        self,
        llm_client,                    # 必需：LLM客户端
        system_prompt: str,            # 必需：系统提示词
        agent_role: str,               # 必需：Agent角色
        memory,                        # 必需：记忆系统
        tools=None,                    # 可选：工具列表
        planning_strategy: str = "auto" # 可选：规划策略
    ):
        """初始化LLM Agent

        Args:
            llm_client: LLM客户端（必需）
            system_prompt: 系统提示词（必需）
            agent_role: Agent角色（必需）
            memory: 记忆系统（必需）
            tools: 工具列表（可选）
            planning_strategy: 规划策略（可选）
        """
        # 核心组件（必需）
        self.llm = llm_client
        self.system_prompt = system_prompt
        self.agent_role = agent_role
        self.memory = memory

        # 增强组件（可选）
        self.tools = tools
        self.planning_strategy = planning_strategy

        # Agent状态
        self.agent_id = str(uuid.uuid4())
        self.created_at = datetime.now()
        self.execution_count = 0
        self.last_activity = None

    async def think(self, input: str) -> AgentResponse:
        """核心思考能力

        这是LLM Agent的核心方法，所有智能行为都从这里开始。

        Args:
            input: 输入信息

        Returns:
            AgentResponse: Agent的思考结果
        """
        # 1. 检索相关记忆
        context = await self._retrieve_context(input)

        # 2. 构建完整提示
        full_prompt = self._build_prompt(input, context)

        # 3. LLM推理
        try:
            response = await self.llm.chat(
                prompt=full_prompt,
                system_prompt=self.system_prompt
            )

            # 4. 存储新记忆
            await self._store_memory(input, response)

            # 5. 更新状态
            self.execution_count += 1
            self.last_activity = datetime.now()

            return AgentResponse(
                content=response.content,
                reasoning=response.reasoning,
                confidence=response.confidence,
                metadata={
                    "agent_id": self.agent_id,
                    "agent_role": self.agent_role,
                    "timestamp": datetime.now().isoformat()
                }
            )

        except Exception as e:
            # 错误时的响应
            return AgentResponse(
                content=f"思考过程出错: {str(e)}",
                confidence=0.0,
                metadata={"error": str(e)}
            )

    async def plan(self, goal: str) -> ExecutionPlan:
        """任务规划能力

        使用LLM自主制定执行计划

        Args:
            goal: 目标描述

        Returns:
            ExecutionPlan: 执行计划
        """
        planning_prompt = f"""
        作为{self.agent_role}，请为以下目标制定详细的执行计划：

        目标: {goal}

        请制定计划，包括：
        1. 任务分解 - 将大任务分解为小步骤
        2. 执行顺序 - 确定步骤的执行顺序
        3. 工具选择 - 确定每步需要的工具
        4. 验证标准 - 确定如何验证每步的成功

        请以结构化的方式输出计划。
        """

        response = await self.think(planning_prompt)

        # 解析LLM返回的计划（简化版）
        # 实际应该有更复杂的解析逻辑
        plan = ExecutionPlan(
            goal=goal,
            steps=self._parse_plan_steps(response.content),
            required_tools=self._extract_required_tools(response.content)
        )

        return plan

    async def execute(self, task: str) -> ExecutionResult:
        """任务执行能力

        自主执行任务的完整流程：
        1. 规划执行步骤
        2. 执行每个步骤
        3. 动态调整计划
        4. 反思总结

        Args:
            task: 任务描述

        Returns:
            ExecutionResult: 执行结果
        """
        try:
            # 1. 规划执行步骤
            plan = await self.plan(task)

            # 2. 执行每个步骤
            results = []
            for i, step in enumerate(plan.steps):
                print(f"执行步骤 {i+1}/{len(plan.steps)}: {step.get('description', '')}")

                # 执行步骤
                step_result = await self._execute_step(step)
                results.append(step_result)

                # 根据结果调整后续步骤
                if not step_result.get("success", True):
                    # 步骤失败，重新规划
                    adjustment = await self.think(
                        f"步骤 '{step.get('description', '')}' 失败，"
                        f"请调整剩余计划: {plan.remaining_steps()}"
                    )
                    plan.update(adjustment.content)

            # 3. 反思总结
            reflection = await self._reflect_on_execution(task, results)

            return ExecutionResult(
                success=all(r.get("success", True) for r in results),
                steps=results,
                reflection=reflection
            )

        except Exception as e:
            return ExecutionResult(
                success=False,
                error=str(e)
            )

    async def reflect(self, task: str, results: List) -> Reflection:
        """反思能力

        对执行过程进行反思，总结经验教训

        Args:
            task: 执行的任务
            results: 执行结果列表

        Returns:
            Reflection: 反思结果
        """
        reflection_prompt = f"""
        作为{self.agent_role}，请对以下任务执行过程进行反思：

        任务: {task}
        执行结果: {results}

        请反思：
        1. 哪些方面做得好？
        2. 哪些方面可以改进？
        3. 学到了什么经验教训？
        4. 下次如何做得更好？
        """

        response = await self.think(reflection_prompt)

        return Reflection(
            insights=response.content,
            improvements="待改进",
            lessons_learned="已记录"
        )

    # === 私有辅助方法 ===

    async def _retrieve_context(self, input: str) -> MemoryContext:
        """检索相关上下文"""
        if self.memory:
            return await self.memory.retrieve(input)
        return MemoryContext()

    def _build_prompt(self, input: str, context: Dict) -> str:
        """构建完整提示"""
        parts = [f"任务: {input}"]

        # 处理短期记忆
        short_term = context.get("short_term", [])
        if short_term:
            parts.append(f"最近上下文: {short_term}")

        # 处理长期记忆
        long_term = context.get("long_term", [])
        if long_term:
            parts.append(f"相关经验: {long_term}")

        # 处理工作记忆
        working = context.get("working", {})
        if working:
            parts.append(f"工作记忆: {working}")

        return "\n\n".join(parts)

    async def _store_memory(self, input: str, response: Dict):
        """存储新记忆"""
        if self.memory:
            await self.memory.store({
                "input": input,
                "response": response,
                "timestamp": datetime.now().isoformat()
            })

    async def _execute_step(self, step: Dict) -> Dict:
        """执行单个步骤"""
        step_type = step.get("type", "thinking")

        if step_type == "thinking":
            # 思考型步骤，使用LLM
            response = await self.think(step.get("description", ""))
            return {
                "success": True,
                "result": response.content,
                "step": step
            }
        elif step_type == "tool_use" and self.tools:
            # 工具使用步骤
            tool_name = step.get("tool")
            params = step.get("parameters", {})
            # 简化实现，实际需要工具注册表
            return {
                "success": True,
                "result": f"执行工具 {tool_name}",
                "step": step
            }
        else:
            # 默认处理
            return {
                "success": True,
                "result": "步骤完成",
                "step": step
            }

    async def _reflect_on_execution(self, task: str, results: List) -> str:
        """对执行过程进行反思"""
        if not results:
            return "没有执行结果可反思"

        reflection_prompt = f"任务: {task}\n结果: {results}\n请总结经验教训"
        response = await self.think(reflection_prompt)
        return response.content

    def _parse_plan_steps(self, plan_text: str) -> List[Dict]:
        """解析计划步骤"""
        # 简化实现，实际需要更复杂的解析逻辑
        return [
            {"description": f"步骤{i+1}", "type": "thinking"}
            for i in range(3)  # 假设总是3个步骤
        ]

    def _extract_required_tools(self, plan_text: str) -> List[str]:
        """提取所需工具"""
        # 简化实现
        return []

    def get_info(self) -> Dict[str, Any]:
        """获取Agent信息"""
        return {
            "agent_id": self.agent_id,
            "agent_role": self.agent_role,
            "created_at": self.created_at.isoformat(),
            "execution_count": self.execution_count,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "has_tools": self.tools is not None,
            "has_memory": self.memory is not None
        }
